---
description: Have the user play a game in the headset and find where it fails — start a playtest, then read its marks, answers and problems
argument-hint: <game: profile key or Steam app id>
---
Help the user playtest `{{args}}` on VXRuntime, then turn what went wrong into the next work.

1. If no game was named, list the installed games (vxrt MCP `list_games`) and ask which one; stop until the user answers.
2. A playtest is the user's: they run it in their own Terminal, with the headset on and their controllers: `python3 tools/vxrt_playtest.py <game>` (the quality tuned for this Mac is used if there is one). Tell them: click both sticks together for about a second where something goes wrong (or press Enter in the Terminal, with a note); quit the game or press Ctrl-C to end; then answer the checklist. Do not start it yourself, and do not run other games meanwhile.
3. When they are done, read it: vxrt MCP `read_playtests` (or `python3 tools/vxrt_playtest.py --show <game>`, and `runs/<id>/playtest.json`). Look at every problem: each mark's frame (`runs/<id>/mark_N.png`) and the game's log at that moment, the "no" answers, crashes, slow stretches, lost tracking.
4. Report: playable or not (which condition failed), and the problems in the order they happened, each with what you think it is (say when it is only a suspicion). Offer `/vxrt-support <game>` for the ones in VXRuntime, `/vxrt-tune <game>` for slow stretches, and `python3 tools/vxrt_playtest.py --apply runs/<id>` (the user's choice) to record it in the game's profile.
5. Talk to the user in their language.
