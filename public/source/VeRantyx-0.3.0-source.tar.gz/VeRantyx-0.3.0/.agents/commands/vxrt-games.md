---
description: Show the Windows VR games installed for VXRuntime, what is known about each, and the latest harness runs (read only)
argument-hint: (no arguments)
---
Show the user which Windows VR games are installed for VXRuntime and their state. Read only: do not run games, do not change files.

1. List them with the vxrt MCP `list_games` (or `python3 tools/vxrt_run.py --list` and `python3 tools/vxrt_games.py list`).
2. For each: name, profile key, status and its summary, known issues, the scenarios with a baseline. Add the newest run in `runs/*/result.json` for the game, if any (run_id, status, fps_median), and say when there is none.
3. End with what the user can ask next: `/vxrt-support <game>`, `/vxrt-tune <game>`, `/vxrt-issue <game>`.
4. Talk to the user in their language.
