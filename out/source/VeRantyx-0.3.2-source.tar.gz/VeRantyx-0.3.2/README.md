<h1 align="center">VeRantyx</h1>

<p align="center"><b>Half-Life: Alyx, Elite Dangerous and No Man's Sky on Apple Vision Pro, from just a Mac.<br>
No gaming PC, no Wine, no CrossOver.</b><br>
Windows PC VR games run on our own Windows runtime, written from scratch for Apple silicon, and stream to Vision Pro
or an ALVR headset. Some also play on the Mac's own screen.</p>

<p align="center">
  <a href="https://github.com/Ag3497120/VeRantyx/releases/latest"><img alt="Download VeRantyx for Mac" src="https://img.shields.io/github/v/release/Ag3497120/VeRantyx?label=VeRantyx%20for%20Mac&logo=apple"></a>
  <img alt="Apple silicon, macOS 14.2+" src="https://img.shields.io/badge/macOS-14.2%2B%20%C2%B7%20Apple%20silicon-black">
  <img alt="Headsets" src="https://img.shields.io/badge/headsets-Vision%20Pro%20%C2%B7%20ALVR-blue">
  <a href="LICENSE"><img alt="MIT license" src="https://img.shields.io/github/license/Ag3497120/VeRantyx"></a>
  <a href="https://discord.gg/h2znwYJt3"><img alt="Discord" src="https://img.shields.io/badge/Discord-join-5865F2?logo=discord&logoColor=white"></a>
</p>

<p align="center">
  <a href="#what-runs"><img src="docs/media/games-highlight.gif" width="720" alt="No Man's Sky, Elite Dangerous and Half-Life: Alyx, Windows builds running on VXRuntime on a MacBook Pro, played in Apple Vision Pro"></a><br>
  <sub>No Man's Sky, Elite Dangerous and Half-Life: Alyx, Windows builds, each on a MacBook Pro M1 Max, no Wine, played in Vision Pro. <a href="https://youtu.be/qF09ETv1TpU">Full 4-minute unedited Alyx recording</a>.</sub>
</p>

> **New in 0.3 (Oct 25-26):** No Man's Sky, on the Mac's screen and in VR, started by your own Windows Steam; ALVR
> app or VeRantyx app chosen per game; "Get and play" downloads a game you own and starts it; fixes for Pico and
> Quest players. **[Download VeRantyx for Mac →](https://github.com/Ag3497120/VeRantyx/releases/latest)** (also on
> [verantyx.ai](https://verantyx.ai))
>
> **In progress:** Direct3D 12 — Cyberpunk 2077 plays in game on the Mac (about 20 fps of real frames, more shown with
> frame prediction) on the [`vr-main`](https://github.com/Ag3497120/VeRantyx/tree/vr-main) branch, not in the app yet;
> and a first attempt to run it standalone on Vision Pro ([`avp-port`](https://github.com/Ag3497120/VeRantyx/tree/avp-port)).

> **Want your game to run? Ask your AI assistant.** VeRantyx is built to be extended with Claude Code, Codex,
> Gemini CLI or Cursor: run `/vxrt-support <your game>` in this repository and the agent measures the game, looks for
> what stops it and tries to implement the missing Windows functions, recording its runs with the test harness
> ([AGENTS.md](AGENTS.md)). Results vary by game; send what you get as a pull request or a report.

**You need your own copy of each game.** No game files, SteamVR or Microsoft DLLs are in this repository or its
releases (only Valve's BSD-licensed OpenVR SDK headers, see [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)):
games and SteamVR come from your own Steam account. No anti-cheat is ever worked around.

**How it's made.** VeRantyx is developed by one person with AI coding agents (mostly Claude Code). Every number in
this README comes from a recorded run, but much of the code has been tested only on the games listed below. It is
not a sandbox: a Windows program under VXRuntime runs with your user's rights, so run only programs you trust.

<p align="center">
  <a href="#get-started">Get started</a> ·
  <a href="#what-runs">What runs</a> ·
  <a href="#updates">Updates</a> ·
  <a href="#under-the-hood">Under the hood</a> ·
  <a href="#branches">Branches</a> ·
  <a href="https://discord.gg/h2znwYJt3">Discord</a> ·
  <a href="docs/README_ja.md">日本語</a>
</p>

## Updates

| Date | What changed |
|---|---|
| Nov 2 | **VeRantyx for Mac 0.3.2**: refresh rate for Quest and Pico (60 / 72 / 90 / 120 Hz; a 60 fps game at 72 Hz judders, #8, #4) and an opt-in UDP stream on Wi-Fi (#8); Elite Dangerous waits for Steam for Mac's sign-in (#10); a warning when the headset's field of view changes after the game started (double vision, #10); logs no longer fill the disk (a repeated line once every 10 s after 20 copies, #4); Half-Life: Alyx's missing `lstrcpynA` (#12); native ARM64 Alyx and the shader cache from #9 (harness, Alyx chapter 1 at 3K on an M1 Max: the longest freeze while playing 1.5 s on the first run, 0.2 s on the second); `gap=` and `stalls=` in the encoder log for freeze reports |
| Oct 30 | **Native ARM64 Alyx merged into `main`** (#9 by medved91): shader caching, a normal quit instead of killing the game, darker shadows/midtones closer to the Windows version, shadow flicker fix. Elite Dangerous: why "this Frontier account does not own Elite" appears when the launcher can't reach Steam (#10) |
| Oct 30 | **Toward Cyberpunk 2077 standalone on Vision Pro** ([`avp-port`](https://github.com/Ag3497120/VeRantyx/tree/avp-port)): VXRuntime builds for visionOS, our Windows test programs run on the headset ahead-of-time compiled (no JIT) and draw in an immersive space at 90 Hz; Cyberpunk itself starts but stops at its memory-pool reservations (the game reserves ~135 GB of address space, apps get ~63 GB). Not playable |
| Oct 27 | **Native ARM64 Alyx in the Mac app**, on `nativeArmRefine`: Windows / Native ARM64 launch mode, a separate installation from the owner's Steam depots, ALVR for Pico / Quest, session supervision, FPS captures and fixes for tracking and controller input ([native notes](NativeARM/README.md)) |
| Oct 27 | **Direct3D 12, first real game**: Cyberpunk 2077 (D3D12 only) gets through its logos, intro video and title to character creation, characters lit correctly; all 20,937 of its non-ray-tracing shaders translate and compile; the stall-heavy CPU side of `ExecuteCommandLists` cut by about half in a synthetic test. Branch [`d3d12-games`](https://github.com/Ag3497120/VeRantyx/tree/d3d12-games), not in the app yet |
| Oct 27 | **[Discord server](https://discord.gg/h2znwYJt3)** opened: setup help, game reports, new versions |
| Oct 27 | My GitHub account is visible again after being hidden by an automated check from Oct 24; the app and the source were served from [verantyx.ai](https://verantyx.ai) meanwhile |
| Oct 26 | **VeRantyx for Mac 0.3.1**: No Man's Sky on the Mac's screen 32.5 → 45.7 fps (tessellation in fewer GPU passes, memory kept resident once); Pico, VIVE and YVR controller speed taken from the hand poses (thrown objects flew as from a cannon); ALVR reconnect mid-game no longer blocked by vibrations (#6 again); Alyx's "Press Trigger To Start" drawn into the picture after a load, where players saw black |
| Oct 25 | **VeRantyx for Mac 0.3.0**: **No Man's Sky** — its DRM needs the real Windows Steam client, so that client now runs on VXRuntime and starts the game (you sign in yourself); Vulkan, tessellation and Vulkan ↔ Direct3D 11 shared textures for SteamVR; ALVR app or VeRantyx app per game; "Get and play" |
| Oct 25 | **VeRantyx for Mac 0.2.2**: Elite Dangerous's launcher updates the game again; ALVR shows the headset's own fps and latency, the bitrate follows the link, "Sharper" really renders more pixels, a paused headset reconnects |
| Oct 23 | **VeRantyx for Mac 0.2.1**: Direct3D 11 games use far less CPU per draw (Alyx busy scene 42-47 → 60 fps, M1 Max); ALVR no longer stuck at "os error 11" after a reconnect (#6); one-click "it ran" and "missing functions" reports after a play; the Wine-derived unwinder replaced ([notice](THIRD_PARTY_NOTICES.md)) |
| Oct 22 | **VeRantyx for Mac 0.2.0**: Elite Dangerous with two buttons, **On this Mac** and **Headset**; the Mac shows its frame rate while you play |
| Oct 22 | **The Lab: controllers work** (any headset): SteamVR now sees The Lab's controller bindings (a Windows pipe call answered wrongly, #2) |
| Oct 22 | ALVR over Wi-Fi: socket buffers fixed at 4 MB, which ended 270-800 ms frame delay spikes (#4); a new headset's first connection no longer shows double vision (#2, #4) |
| Oct 22 | **Vulkan, first steps** in our own `vulkan-1.dll`: a Windows program draws with depth test, culling, uniform buffers and push constants, and presents to a window. Next: what real games need (No Man's Sky, X-Plane 12) |
| Oct 22 | Elite Dangerous: PS5 DualSense in game; plays flat on the Mac's screen (about 60 fps in game, M1 Max) |
| Oct 21 | Elite Dangerous reaches the headset: official launcher (WPF on our own .NET runtime), sign-in, game, SteamVR (30-35 fps at 1700×1372 per eye) |
| Oct 18 | **VeRantyx for Mac 0.1.0**: setup and play without Terminal, signed and notarized, 11 languages |
| Oct 18 | Direct3D 12 steps 1-5: DXIL read without LLVM, translated to Metal, compute, graphics and swap chains |
| Oct 17 | The Lab runs on our own x86-64 → ARM64 translator (the path that replaces Rosetta 2), 52-56 fps |
| Oct 12 | VXRuntime, the Windows runtime, starts from scratch |

## Help wanted: does it run for you?

The fastest way to grow the list of games and headsets is your report, whether it works or not:
**[Report a game or headset →](https://github.com/Ag3497120/VeRantyx/issues/new/choose)** (in the app: Help >
Report a problem; it attaches the logs with your user name and Steam ID taken out). Quest and Pico are tested by
players only so far.

Questions, or want to share what you got running? **[Join the Discord →](https://discord.gg/h2znwYJt3)** (#setup-help for installing and
connecting, #game-reports for one post per game).

## Get started

1. **[Download VeRantyx for Mac](https://github.com/Ag3497120/VeRantyx/releases/latest)** — signed and notarized by
   Apple. Drag it to Applications. The runtime is inside: you need only macOS and Steam.
2. **Get started** in the app: it checks the Mac, gets SteamVR and your games' Windows builds with *your own* Steam
   account (or copies them from a Steam library you already have), and gathers the Microsoft runtime files from
   their own installers.
3. **Pick your headset and press Play.**

That's it. Details, languages (11) and what is checked: [MacApp/README.md](MacApp/README.md).
Prefer Terminal? `scripts/setup_vxrt.sh` then `scripts/launch_vxrt_alyx.sh` — see [the vxrt guide](docs/VXRT.md#quick-start).

<p align="center">
  <img src="docs/media/app-setup.png" width="32%" alt="VeRantyx for Mac: Get started, every step checked">
  <img src="docs/media/app-play.png" width="32%" alt="VeRantyx for Mac: Play, the installed games with what is known about each">
  <img src="docs/media/app-headset.png" width="32%" alt="VeRantyx for Mac: Headset, Vision Pro with hands and Joy-Con, or ALVR headsets">
</p>

## What runs

| Game | Status on VXRuntime | Measured |
|---|---|---|
| **Half-Life: Alyx** | ✅ Playable — played in the headset across level changes and saves | 60 fps at the 3K preset (1440×1620 per eye), MacBook Pro M1 Max |
| **Google Earth VR** | 🟡 Runs in VR, playtest pending | 56.7 fps, M1 Max |
| **Elite Dangerous** | 🟡 Flies on the Mac's screen and in the headset (official launcher; keyboard, mouse, DualSense) | flat: about 52-122 fps in game; VR: 30-35 fps at 1700×1372 per eye; M1 Max, Low |
| **No Man's Sky** | 🟡 Played on the Mac's screen (terrain drawn); in VR, picture and sound checked with both the Vision Pro's VeRantyx app and the ALVR app (hand input through ALVR too). Started by your own Windows Steam on VXRuntime (its DRM wrapper needs that Steam; you sign in yourself) | flat: 45.7 fps (1512×982, Medium, on a planet, 0.3.1); headset: 25-40 fps measured before 0.3.1 |
| **Cyberpunk 2077** | 🧪 Direct3D 12, in progress on the `vr-main` branch (not in the app): in game on the Mac's screen with NPU frame prediction; not playable in the headset yet | El Coyote, Low, FSR2 Performance: about 20 fps of real frames, about 50 shown with prediction (M1 Max) |
| **The Lab** | 🟡 Runs in VR, but only the title scene has been measured; the mini-games are not optimized yet (a player saw 20-30 fps) | title scene 54.0 fps, M1 Max |
| Other SteamVR games | ⚪ Most still need Windows functions VXRuntime lacks | [games/](games/) has what is known |

Checked on a MacBook Pro M1 Max (most numbers) and a MacBook Air M5 (some games). Numbers come from harness runs with their run ids in
[games/](games/), or from the recorded play named next to them. Not supported yet: Direct3D 12 games in the app
(in progress, above), ray tracing; anti-cheat is never worked around.

| Headset | How | Status |
|---|---|---|
| **Apple Vision Pro** (checked on M2) | VeRantyx app: hand tracking + Joy-Con, or bare hands — **no VR controllers needed** | ✅ Checked |
| **Apple Vision Pro** | "ALVR" app from the App Store | ✅ Checked (Alyx, Earth VR) |
| **Meta Quest, Pico** | ALVR 20.x, Wi-Fi or USB cable | 🟡 Played by testers (Quest 1, Quest 3, Pico 4 Ultra); not tested by me — [reports welcome](https://github.com/Ag3497120/VeRantyx/issues/new?template=alvr-headset.yml) |

## Under the hood

Everything below is in this repository, MIT licensed, and was written for this project (with the exceptions listed in
[THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)).

- **VXRuntime — a Windows runtime written from scratch for Apple silicon.** No Wine, no wineserver: a PE loader and
  the Windows API (kernel32, exceptions, files and registry, windows on AppKit, COM, audio on Core Audio) as native
  code that Windows programs call directly. It uses no Wine code, except about 120 lines of the x64 exception
  unwinder in versions from 2026-10-12 to 2026-10-23 (mac-v0.1.0, mac-v0.2.0), which were derived from Wine and have
  since been replaced ([THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)). [VXRuntime/](VXRuntime/README.md)
- **Direct3D 11 → Metal in one step.** Our own DXBC → Metal Shading Language translator; geometry shaders and
  stream output run as compute. Alyx went from ~30 fps under Wine (DXVK → MoltenVK) to 60 fps on the same Mac.
- **Vulkan → Metal.** Our own SPIR-V → Metal Shading Language translator in `vulkan-1.dll`, with tessellation and
  Vulkan textures shared with Direct3D 11 (for SteamVR). No Man's Sky runs on it.
- **Direct3D 12 → Metal, from scratch.** A DXIL reader with no LLVM, a DXIL → MSL translator and `d3d12.dll` on
  Metal: root signatures, descriptor heaps, tiled resources, tessellation and geometry shaders, wave ops, 16-bit
  types. On the `d3d12-games` branch, Cyberpunk 2077 reaches character creation; no D3D12 game is playable yet.
- **The real Windows SteamVR on the Mac.** vrserver and vrcompositor run on VXRuntime with our driver; textures cross
  processes as IOSurfaces. Most games talk to the **Mac** Steam client through a bridge — no Windows Steam, no Chromium. Games whose
  executable is wrapped in Steam's DRM (No Man's Sky) start from the real Windows Steam client, which runs on
  VXRuntime too and which you sign in to yourself.
- **HEVC streaming.** VideoToolbox HEVC (10-bit at the 3K preset) to our visionOS app, each frame at the exact pose and
  frustum it was rendered for — or through ALVR's own streaming core to ALVR clients, over Wi-Fi or a USB cable.
- **A notarized SwiftUI Mac app** that does the whole setup without Terminal, in 11 languages.
- **Our own x86-64 → ARM64 translator (in progress)** for when Rosetta 2 goes away: Google Earth VR has run on it;
  not used for games by default. [TRANSLATOR.md](VXRuntime/TRANSLATOR.md)
- **Built for AI coding agents.** `/vxrt-support <game>` and `/vxrt-tune <game>` in Claude Code, Codex, Gemini CLI and
  Cursor; a harness that measures runs into evidence (observed values with file hashes, sealed in a hash-chained
  ledger); an MCP server; [Command Clips](VXRuntime/CLIPS.md) to operate Windows programs without screenshots.
  [AGENTS.md](AGENTS.md)

## Branches

| Branch | What it is | For | Status |
|---|---|---|---|
| **[`main`](https://github.com/Ag3497120/VeRantyx)** | Windows games + real SteamVR on **VXRuntime**, and native ARM64 Alyx in the Mac app (merged from `nativeArmRefine`) | Players (via the app) and developers | ⭐ Current — [full guide](docs/VXRT.md), [native notes](NativeARM/README.md) |
| [`vr-main`](https://github.com/Ag3497120/VeRantyx/tree/vr-main) | Direct3D 12 (Cyberpunk 2077), NPU frame prediction, stereo, MetalFX, ahead-of-time ARM64 compilation, merged | Developers | 🧪 Work in progress, not in the app |
| [`avp-port`](https://github.com/Ag3497120/VeRantyx/tree/avp-port) | VXRuntime on visionOS: Windows games standalone on Vision Pro | Developers | 🧪 Experimental: test programs run, no game yet |
| [`d3d12-games`](https://github.com/Ag3497120/VeRantyx/tree/d3d12-games) | Direct3D 12 toward real games (included in `vr-main`) | Developers | 🧪 Work in progress |
| [`native`](https://github.com/Ag3497120/VeRantyx/tree/native) | Valve's **Linux ARM64** Alyx runs natively on macOS (patched Klepton + our OpenVR runtime) | Alyx only; the fastest path, no CPU translation | Paused since 2026-10-11 (the code is also in `main` under `NativeARM/`) |
| [`wine`](https://github.com/Ag3497120/VeRantyx/tree/wine) | Windows build + real SteamVR under **Wine 11**, DXVK → MoltenVK | Reference / history | Kept as of 2026-10-10, ~30 fps |

All Mac-side versions share the HEVC encoder (`MacEncoder/`) and the Vision Pro app (`VisionProClient/`).

## Your games, your copy

No Valve, Microsoft or game files are in this repository or its releases. SteamVR and the games come from your own
Steam account; Microsoft's runtime DLLs are taken from the redistributable installers your own installs carry, on your
Mac only. Licenses: [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md). Not affiliated with Valve, Apple, Microsoft,
Meta, Nintendo, Sony, ALVR, Glovebox or Klepton.

**Help wanted:** Quest and Pico reports (works or not), and game profiles with harness runs as evidence
([games/README.md](games/README.md)). MIT © 2026 Ag3497120 (earlier versions contained about 120 lines of
Wine-derived LGPL code: see [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)).
